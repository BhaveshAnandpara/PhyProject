
function navFunctionOpen(){

    $('.nav').css("transform" , "translateX(0%)");
    $('.main').css("transform" , "translateX(15%)")
}

function navFunctionClose(){

    $('.nav').css("transform" , "translateX(-100%)")
    $('.main').css("transform" , "translateX(0%)")
}




